package com.example.calendarapp;		//My package name

public class DeleteAppointment {		//Public method declared
}
